﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Assg3_sxs180366
{
    public partial class Form1 : Form
    {
        //Vairaible to hold evaluation metrics
        int numRec;

        public Form1()
        {
            InitializeComponent();
        }

        //Browse Files Button
        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog open_file = new OpenFileDialog();
            open_file.Filter = "Text File | *.txt";
            open_file.ShowDialog();
            textBox1.Text = open_file.FileName;
            InvalidInput.Clear();
        }

        //Evaluate Button
        private void button3_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text))
                MessageBox.Show("Choose a text file!");
            else
            {
                //number of records
                get_NumRec();
                //backspace and time metrics
                eval_Rec();
            }

        }

        //Function to get number of records in file
        private void get_NumRec()
        {
            //number of records
            numRec = File.ReadLines(textBox1.Text).Count();
            textBox2.Text = numRec.ToString();
        }

        //Function to evaluate time metrics
        private void eval_Rec()
        {
            //read the source file
            StreamReader sr = new StreamReader(textBox1.Text);

            DateTime[] startTime = new DateTime[numRec];
            DateTime[] endTime = new DateTime[numRec];
            int[] backspaceCount = new int[numRec];
            int i = 0;
            
            //Store startTime, endTime and backspaceCount for each ith record
            while (sr.Peek() > -1)
            {
                string s = sr.ReadLine();
                string[] element = s.Split('\t');
                
                //Ensure valid data
                if(element.Length<16 || !(DateTime.TryParse(element[14], out DateTime Temp1) == true
                    && DateTime.TryParse(element[15], out DateTime Temp2) == true
                    && int.TryParse(element[16], out int val) == true))
                {
                    InvalidInput.SetError(button3, "Invalid Input. Try a different input file.");
                    textBox2.Text="";
                    return;
                }
                startTime[i] = DateTime.Parse(element[14]);
                endTime[i] = DateTime.Parse(element[15]);
                backspaceCount[i] = int.Parse(element[16]);
                i++;
            }
            sr.Close();

            //variables to store time per record and its sum
            TimeSpan[] recTime = new TimeSpan[numRec];
            TimeSpan sum_recTime = TimeSpan.Zero; 
            //variables to store time between each record and its sum
            TimeSpan[] consecutive_recTime = new TimeSpan[numRec - 1];
            TimeSpan sum_consecutive_recTime = TimeSpan.Zero;          

            //calculate values
            for (int j = 0; j < numRec; j++)
            {
                recTime[j] = endTime[j] - startTime[j];
                sum_recTime = sum_recTime + recTime[j];
                if(j< (numRec - 1))
                {
                    consecutive_recTime[j] = startTime[j + 1] - endTime[j];
                    sum_consecutive_recTime = sum_consecutive_recTime + consecutive_recTime[j];
                }
            }
            //each record metrics
            TimeSpan max_recTime = recTime.Max();
            TimeSpan min_recTime = recTime.Min();
            TimeSpan avg_recTime = new TimeSpan(sum_recTime.Ticks / numRec);

            //inter-record metrics
            TimeSpan max_consecutive_recTime = TimeSpan.Zero;
            TimeSpan min_consecutive_recTime = TimeSpan.Zero;
            TimeSpan avg_consecutive_recTime = TimeSpan.Zero;

            if(numRec!=0)
            {
                max_consecutive_recTime = consecutive_recTime.Max();
                min_consecutive_recTime = consecutive_recTime.Min();
                avg_consecutive_recTime = new TimeSpan(sum_consecutive_recTime.Ticks / (numRec - 1));
            }

            //total number of backspaces
            int backcountsum = backspaceCount.Sum();
            //total record entry time
            TimeSpan total_time = endTime[numRec - 1] - startTime[0];

            //display metrics 
            textBox3.Text = min_recTime.ToString(@"mm\:ss");
            textBox4.Text = max_recTime.ToString(@"mm\:ss");
            textBox5.Text = avg_recTime.ToString(@"mm\:ss");
            textBox6.Text = min_consecutive_recTime.ToString(@"mm\:ss");
            textBox7.Text = max_consecutive_recTime.ToString(@"mm\:ss");
            textBox8.Text = avg_consecutive_recTime.ToString(@"mm\:ss");
            textBox9.Text = total_time.ToString(@"mm\:ss");
            textBox10.Text = backcountsum.ToString();

        }

        //Function to save metrics to file
        private void button2_Click(object sender, EventArgs e)
        {
            SaveFileDialog save_file = new SaveFileDialog();
            save_file.FileName = "CS6326Evaluation.txt";
            save_file.Filter = "Text File | *.txt";
            if (save_file.ShowDialog() == DialogResult.OK)
            {
                StreamWriter sr = new StreamWriter(save_file.OpenFile());

                sr.WriteLine("Number of Records: " + textBox2.Text);
                sr.WriteLine("Minimum Entry Time: " + textBox3.Text);
                sr.WriteLine("Maximum Entry Time: " + textBox4.Text);
                sr.WriteLine("Average Entry Time: " + textBox5.Text);
                sr.WriteLine("Minimum inter-Record Time: " + textBox6.Text);
                sr.WriteLine("Maximum inter-Record Time: " + textBox7.Text);
                sr.WriteLine("Average inter-Record Time: " + textBox8.Text);
                sr.WriteLine("Total Time: " + textBox9.Text);
                sr.WriteLine("Backspace Count: " + textBox10.Text);

                sr.Close();
            }
        }
    }
}
